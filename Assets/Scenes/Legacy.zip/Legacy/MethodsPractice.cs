using UnityEngine;

class MethodsPractice : MonoBehaviour
{
    [SerializeField] int multiplicationBase;
    [SerializeField] float a, minimum, maximum;

    void Start()
    {
        Debug.Log("Hello1");   // Elj�r�s
        Debug.Log("Hello2");
        Debug.Log("Hello3");

        int min = Mathf.Min(1, 4, 5, 6);      // F�ggv�ny
        int max = Mathf.Max(1, 4, 5, 6);
        float abs = Mathf.Abs(-20);           // Absolute Value
        float pow = Mathf.Pow(3, 4);          // power / Hatv�nyoz�s
        float sqrt = Mathf.Sqrt(5);           // N�gyzetgy�k
        float round = Mathf.Round(11.9f);     // Kerek�t�s   (12)
        int round2 = Mathf.RoundToInt(11.9f); // Kerek�t�s   (12)
        float ceil = Mathf.Ceil(12.1f);       // Ceiling / Plafon    (13)
        float floor = Mathf.Floor(44.9f);     // Padl� (44)
        float sign = Mathf.Sign(-122);        // El�jel: 1 vagy -1   (-1)
        float clamped = Mathf.Clamp(10, 0, 100);   // Beszor�t�s k�t �rt�k k�z�   (10)
        float c2 = Mathf.Clamp(10, 100, 200);      // (100)
        
        float hp = 99;
        float c3 = Mathf.Clamp(hp, 0, 100);   // 99

        int min2 = Minimum(45, 67);   // 45
        int min3 = Minimum(23, 11);   // 11
        int min4 = Minimum(-88, 01);  // -88
        
        WriteMultiplicationTable(multiplicationBase);
        WriteMultiplicationTable(4);
        WriteMultiplicationTable(5);

        int abs2 = Abs(-33);
        a = Clamp(a, minimum, maximum);
        float xce = Clamp(c3, 0, 100);
    }

    int Minimum(int a, int b)
    {
        return a < b ? a : b;
    }

    float Clamp(float number, float min, float max) 
    {
        if (number < min)
            return min;

        if (number > max)
            return max;
        
        return number;
    }

    int Abs(int number)
    {
        if (number > 0)
            return number;
        else
            return -number;
    }

    void WriteMultiplicationTable(int baseNumber)
    {
        for (int i = 1; i <= baseNumber; i++)
        {
            for (int j = 1; j <= baseNumber; j++)
            {
                Debug.Log($"{j} * {i} = {i * j}");
            }
        }
    }
}
